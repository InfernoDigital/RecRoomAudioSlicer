# Rec Room Audio Slicer v1.1
# Created by Stormy of InfernoDigital
# v1.0 Finalized 4/21/2021
#
# - Instructions -
#
# Step 0. Open JES using the included shortcut (dont open the RRAS.py file yet)
#
# Step 1. Find your music and make it into a .wav file (most likely using Audacity)
#
# Step 2. rename your wav to song.wav and place it in the included in_out folder.
#
# Step 3. Open This .py file in JES 6.0
#
# Step 4. Load and run the program to create your clips!
#
# Then follow any youtube tutorial on how to record those clips into Rec Room and enjoy!
#

import time

print "Loading Splicer"
time.sleep(2)
print "FAQ - Exact Cut is a song that ends exactly on a 30 second mark"
time.sleep(3)

# Loop used to clear space in the console
count = 0
while count < 1:
  count = count+1
 




# This next set of commands finds the input folder and the song.wav file we want to splice.
file = getMediaPath("song.wav")

sound = makeSound(file)

print" "
print "Song Discovery Complete"
print" "

time.sleep(1)





#Find total samples and samples-per-second rate, then prints them.
SampleLength = getLength(sound)
SampleRate = getSamplingRate(sound)
intSR = int(SampleRate)

print "Total Samples =", SampleLength
print "Samples Per Second =", SampleRate





# trunkated division of the amount of samples by the sample rate per second, plus 1 because it rounds down not up)
SongLength = (SampleLength / SampleRate)

TSongLength = ((SampleLength // SampleRate)+1)





# SPACE

print "Audio File Total Seconds =", SongLength

print " "

time.sleep(1)

print "Is Song Length an Integer? = ",(SongLength).is_integer()

RecorderLimit = 30

def multiple(m, n):
	return True if m % n == 0 else False

ExactCut = (multiple(SongLength, RecorderLimit))

print "Is this song an Exact Cut? =", ExactCut

time.sleep(1)

print " "

print "Calculating Necessary Splices"

SpliceNumber = (TSongLength // 30)

if ExactCut:

  print "Accepted Numerator"
  Slices = SpliceNumber
  
else: 

  print "Numerator is spliced. Computing..."
# AccuSliceNum is used if we have a song that doesn't end on an ExactCut. It basically adds an extra slice.
  Slices = int(round(SpliceNumber)+1)

print " "
time.sleep(1)

print "Number of Slices =", Slices
print " "
  



    



# BELOW THIS LINE IS THE SPLICER PROGRAM


    

audiocount = 0

newSound = makeEmptySoundBySeconds(30, intSR)

while audiocount < Slices:
  print "Computing Slice...", audiocount+1
  for index in range(intSR*(audiocount*30),intSR*((audiocount*30)+30)):
    if index < SampleLength-1:
      OldSample = getSampleObjectAt(sound, index)
      OldValue = getSampleValue(OldSample)
      setSampleValueAt(newSound,index-(intSR*audiocount*30),OldValue)
      
    else:
      setSampleValueAt(newSound,index-(intSR*audiocount*30),0)

      
 
  setMediaPath("/in_out/")
  writeSoundTo(newSound, "clip{}.wav".format(audiocount+1))
  audiocount = audiocount+1 



