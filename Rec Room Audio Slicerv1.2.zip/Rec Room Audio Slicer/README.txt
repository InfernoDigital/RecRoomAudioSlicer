A jython JES program designed to quickly and easily slice audio files into 30 second segments, so they can more easily be added to Rec Room with audio samplers!

Rec Room Audio Slicer v1.2</br>
Created by StormyDoesVR</br>
v1.2 Finalized 3/21/2022</br>

#

- Instructions -

Step 0. Download, install, and run Jython from this link - https://github.com/gatech-csl/jes

Step 1. Find your music and make it into a .wav file (most likely using Audacity)

Step 2. rename your wav to song.wav and place it in the included in_out folder.

Step 3. Open This .py file in JES 6.0

Step 4. Load and run the program to create your clips!

Step 5. Visit the tutorial room at the Rec Room Audio Shop to learn how to import those clips into Rec Room!

Credit for the example song goes to djgriffin - https://freesound.org/people/djgriffin/sounds/172561/